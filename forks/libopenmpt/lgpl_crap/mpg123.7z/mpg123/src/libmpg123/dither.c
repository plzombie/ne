/* Hack to allow building the same code with and without libtool. */
#include "intsym.h"
#include "dither_impl.h"
